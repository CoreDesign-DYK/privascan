# PrivaScan Release Keystore

이 폴더는 gitignore 처리되어 있습니다. 절대 커밋하지 마세요.

## 파일 설명
- `privascan-release.p12` — Android 앱 서명용 PKCS12 키스토어

## GitHub Secrets (이미 등록됨 ✅)
- `KEYSTORE_BASE64` — p12 파일의 base64 인코딩 값
- `KEYSTORE_PASSWORD` — 키스토어 비밀번호
- `KEYSTORE_ALIAS` — 키 별칭 (privascan)

## 키스토어 분실 시
키스토어를 분실하면 동일한 package name으로 Play Store 업데이트가 불가능합니다.
이 파일을 안전한 곳(1Password, Google Drive 등)에 백업해두세요.

## 키스토어 정보
- Format: PKCS12 (.p12)
- Key algorithm: RSA 2048
- Validity: 10,000일 (~27년)
- Alias: privascan
