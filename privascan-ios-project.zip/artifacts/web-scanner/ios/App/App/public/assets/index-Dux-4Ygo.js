const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-CXYpDESu.js","assets/index-BtqBsdI3.js"])))=>i.map(i=>d[i]);
import{_ as e}from"./index-D2uiyxb7.js";import{r as o}from"./index-BtqBsdI3.js";const i=o("Share",{web:()=>e(()=>import("./web-CXYpDESu.js"),__vite__mapDeps([0,1])).then(r=>new r.ShareWeb)});export{i as Share};
